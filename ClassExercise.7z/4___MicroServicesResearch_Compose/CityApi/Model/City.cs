﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CityApi.Model
{
    public class City
    {
        public int CID { get; set; }
        public string Name { get; set; }
    }
}
