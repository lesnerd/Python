﻿using System;
using System.Collections.Generic;

namespace UserApi.Models
{
    public partial class Users
    {
        public int Uid { get; set; }
        public string Name { get; set; }
        public double? Salary { get; set; }
        public int? CityId { get; set; }

        public virtual Cities City { get; set; }
    }
}
