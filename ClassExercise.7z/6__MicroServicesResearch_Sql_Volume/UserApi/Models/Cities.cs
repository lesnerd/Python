﻿using System;
using System.Collections.Generic;

namespace UserApi.Models
{
    public partial class Cities
    {
        public Cities()
        {
            Users = new HashSet<Users>();
        }

        public int Cid { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Users> Users { get; set; }
    }
}
