﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using UserApi.Model;
using UserApi.Models;

namespace UserApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly ILogger<UserController> _logger;
        private UserRepository repository = null;
        private AAAContext context = null;

        public UserController(
            ILogger<UserController> logger, 
            UserRepository repository,
            DbContext context)
        {
            _logger = logger;
            this.repository = repository;
            this.context = context as AAAContext;
        }

        [HttpGet]
        public IEnumerable<Users> Get()
        {
            // return repository.GetAll();
            return context.Users;
        }

        [HttpGet("{id}")]
        public async Task<UserAdv> Get(int id)
        {
            // return await repository.GetById(id);
            var resultUser= await context.Users.Include("City").FirstOrDefaultAsync(u => u.Uid == id);
            
            var user = new UserAdv();
            user.UID = resultUser.Uid;
            user.Name = resultUser.Name;
            user.Salary = (int)resultUser.Salary;
            user.CityId = (int)resultUser.CityId;
            user.CityName = resultUser.City.Name;

            return user;
        }

        //[HttpGet("{id}")]
        //public Users Get(int id)
        //{
        //    return context.Users.FirstOrDefault(u => u.Uid == id);
        //}

        [HttpPost] 
        public void Post(User user)
        {
            repository.Add(user);
        }
    }
}
