﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IProductRepository repo;

        public ProductController(IProductRepository repo)
        {
            this.repo = repo;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            // ...
            await Task.Delay(0);
            return Ok(repo.GetAll());
        }

        //[HttpGet]
        //public IActionResult Get()
        //{
        //    return Ok(repo.GetAll());
        //}

        [HttpGet("{id}")]
        public IActionResult GetByID(int id)
        {
            var p = repo.GetByID(id);
            if (p != null)
                return Ok(p);
            else
            {
                ModelState.AddModelError("id", $"Can not find {id}");
                return NotFound(ModelState);
            }
        }

        //[HttpPost]
        //public IActionResult Post(Product p)
        //{
        //    if (p.UnitPrice<0)
        //        ModelState.AddModelError("UnitPrice", $"Price must be positive or 0: {p.UnitPrice}");

        //    if (ModelState.IsValid)
        //    {
        //        repo.AddNew(p);
        //        return Ok("Post OK");
        //    }
        //    else
        //        return BadRequest(ModelState);

        //}

        [HttpPost]
        public IActionResult Post(Product p)
        {
            repo.AddNew(p);
            return Ok("Post OK");
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, Product p)
        {
            repo.Update(id, p);
            return Ok("Put OK");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                repo.Delete(id);
                return Ok("Delete OK");
            }
            catch(Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
