﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp
{
    public static class CounterExtensions
    {
        public static IApplicationBuilder UseCounter(this IApplicationBuilder builder)
        {
            //builder.Use((context, next) =>
            //{
            //    if (context.Request.Method == "GET" && context.Request.Path.Value.ToUpper() != "/COUNTER")
            //    {
            //        Globals.Counter++;
            //    }

            //    return next();
            //});
            //return builder;
            
            return builder.UseMiddleware<CounterMiddleware>();
        }
    }
}
