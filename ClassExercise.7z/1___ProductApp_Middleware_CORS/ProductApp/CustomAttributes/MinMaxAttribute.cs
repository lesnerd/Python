﻿using ProductApp.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp.CustomAttributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class MinMaxAttribute : ValidationAttribute 
    {
        public override bool IsValid(object value)
        {
            // var p = (Product)value;
            var p = value as Product;
            if (p!=null) 
                return p.Min<=p.Max;
            throw new Exception("Illegal attribute");
        }
    }
}
