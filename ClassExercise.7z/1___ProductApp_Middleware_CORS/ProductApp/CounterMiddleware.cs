﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp
{
    public class CounterMiddleware
    {
        private RequestDelegate _next;
        public CounterMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public Task Invoke(HttpContext context)
        {
            if (context.Request.Method == "GET" && context.Request.Path.Value.ToUpper() != "/COUNTER")
            {
                Globals.Counter++;
            }

            return _next(context);
        }
    }
}
