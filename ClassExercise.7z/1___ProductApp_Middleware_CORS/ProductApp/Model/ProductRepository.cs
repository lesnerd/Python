﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp.Model
{
    public class ProductRepository : IProductRepository
    {
        private List<Product> products = new List<Product>
        {
            new Product {ProductID=111, ProductName="Chair", UnitPrice=250},
            new Product {ProductID=222, ProductName="Table", UnitPrice=1400},
            new Product {ProductID=333, ProductName="Pen", UnitPrice=10},
        };

        public IEnumerable<Product> GetAll()
        {
            return products;
        }

        public Product GetByID(int id)
        {
            return products.FirstOrDefault(p => p.ProductID == id);
        }

        public void AddNew(Product p)
        {
            products.Add(p);
        }

        public void Update(int id, Product p)
        {
            var productToUpdate = GetByID(id);
            if (productToUpdate != null)
            {
                productToUpdate.ProductID = p.ProductID;
                productToUpdate.ProductName = p.ProductName;
                productToUpdate.UnitPrice = p.UnitPrice;
            }
        }

        public void Delete(int id)
        {
            products.RemoveAll(p => p.ProductID == id);
        }
    }
}
