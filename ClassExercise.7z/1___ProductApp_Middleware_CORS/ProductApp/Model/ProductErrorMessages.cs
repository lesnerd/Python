﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp.Model
{
    public static class ProductErrorMessages
    {
        public static string ProductIdError { 
            get
            {
                return "ATTN: Illegal id";
            }
        }
    }
}
