﻿using System.Collections.Generic;

namespace ProductApp.Model
{
    public interface IProductRepository
    {
        void AddNew(Product p);
        IEnumerable<Product> GetAll();
        Product GetByID(int id);
        void Update(int id, Product p);
        void Delete(int id);
    }
}