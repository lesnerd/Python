﻿using Microsoft.AspNetCore.Mvc;
using ProductApp.CustomAttributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductApp.Model
{
    [ModelMetadataType(typeof(ProductMetadata))]
    public partial class Product { }

    [MinMax(ErrorMessage = "Error: Min>Max")]
    public class ProductMetadata
    {
        // [Range(100,10000, ErrorMessage = "ATTN: Illegal id")]
        [Range(100, 10000, ErrorMessageResourceType = typeof(ProductErrorMessages), ErrorMessageResourceName = "ProductIdError")]
        public int ProductID { get; set; }
        [StringLength(30, ErrorMessage = "ATTN: Illegal name length")]
        public string ProductName { get; set; }
        [Range(0, 100000, ErrorMessage = "ATTN: Illegal price")]
        public double UnitPrice { get; set; }
        [Range(0, 100000, ErrorMessage = "ATTN: Illegal minimum")]
        public int Min { get; set; }
        [Range(0, 100000, ErrorMessage = "ATTN: Illegal maximum")]
        public int Max { get; set; }
        //[MinMaxTrial(4,78, Count = 19)]
        //public int Stock { get; set; }
    }
}
